package com.rejash.sendemail.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rejash.sendemail.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long>{

}
