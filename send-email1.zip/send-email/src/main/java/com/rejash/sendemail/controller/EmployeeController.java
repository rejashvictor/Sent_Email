package com.rejash.sendemail.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rejash.sendemail.model.Employee;
import com.rejash.sendemail.repository.EmployeeRepository;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeRepository employeeRepository;
	
	@GetMapping("get-all-employee")
	public List<Employee> getAllEmployee() {
		return employeeRepository.findAll();
	}
	
	@PostMapping("/add-employee")
	public String addEmployee(@RequestBody Employee employee) {
		employeeRepository.save(employee);
		return "Saved";
	}
	
	@DeleteMapping("delete-employee/{id}")
	public String deleteEmployee(@PathVariable Long id) {
		Employee emp = employeeRepository.getById(id);
		employeeRepository.delete(emp);
		return "Deleted";
	}
}
