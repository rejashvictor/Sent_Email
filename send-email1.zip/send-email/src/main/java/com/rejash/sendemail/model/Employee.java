package com.rejash.sendemail.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {
	
	@Id
	public Long id;
	
	public String name;
	
	public String salary;
		
}